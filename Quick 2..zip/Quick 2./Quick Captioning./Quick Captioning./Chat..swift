//
//  Chat..swift
//  Quick Captioning.
//
//  Created by Anshul Kumaria on 25/11/25.
//

import Foundation
struct ChatMessage {
    let text: String
    let isIncoming: Bool // true = Gray (Left), false = Blue (Right)
    let sender: String
}
