//
//  ViewController.swift
//  Quick Captioning.
//
//  Created by Anshul Kumaria on 25/11/25.
//

import UIKit

class QuickCaptioningViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource{
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var pauseButton: UIButton!
    
    @IBOutlet weak var micButton: UIButton!
    
    @IBOutlet weak var endButton: UIButton!
    
    var messages: [ChatMessage] = [
        // 1. Incoming
        ChatMessage(text: "You want me to drop you at the gate or that building? Same fare.", isIncoming: true, sender: "Person 1"),
        
        // 2. Outgoing
        ChatMessage(text: "The gate would be fine, thanks.", isIncoming: false, sender: "Me"),
        
        // 3. Incoming
        ChatMessage(text: "What is the code, Sir?", isIncoming: true, sender: "Person 1"),
        
        // 4. Outgoing
        ChatMessage(text: "The code is 10042005.", isIncoming: false, sender: "Me"),
        
        // 5. Incoming (New)
        ChatMessage(text: "The fare is 120 bucks, Sir. Cash please.", isIncoming: true, sender: "Person 1"),
        
        // 6. Outgoing (New)
        ChatMessage(text: "120! Jesus, the fare has sky-rocketed a lot!", isIncoming: false, sender: "Me"),
        
        // 7. Incoming (New)
        ChatMessage(text: "I know, Sir. But after inflation, this is the best we can do.", isIncoming: true, sender: "Person 1"),
        
        // 8. Outgoing (New)
        ChatMessage(text: "Public transport would have been cheaper.", isIncoming: false, sender: "Me")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.keyboardDismissMode = .interactive
    }

    // MARK: - CollectionView Data Source
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let message = messages[indexPath.row]
        
        if message.isIncoming {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IncomingCell", for: indexPath) as! IncomingCell
            cell.messageLabel.text = message.text
            cell.nameLabel.text = message.sender
            
            // Dynamic Sizing Layout Fix
            cell.contentView.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width).isActive = true
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OutgoingCell", for: indexPath) as! OutgoingCell
            cell.messageLabel.text = message.text
            
            // Dynamic Sizing Layout Fix
            cell.contentView.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width).isActive = true
            return cell
        }
    }
}
