//
//  ChatCell.swift
//  Quick Captioning.
//
//  Created by Anshul Kumaria on 25/11/25.
//

import UIKit

class OutgoingCell: UICollectionViewCell {
    @IBOutlet weak var bubbleView: UIView!
    @IBOutlet weak var messageLabel: UILabel!
    
    override func awakeFromNib() {
            super.awakeFromNib()
            
            // 1. Visuals
            bubbleView.backgroundColor = .systemBlue
            messageLabel.textColor = .white
            bubbleView.layer.cornerRadius = 16
            bubbleView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner]
            
            // 2. THE FIX: Force the cell width to match the Screen Width
            // This prevents the "Collapse" issue.
            contentView.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width).isActive = true
        }
    }

class IncomingCell: UICollectionViewCell {
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var bubbleView: UIView!
    @IBOutlet weak var messageLabel: UILabel!
    
    override func awakeFromNib() {
            super.awakeFromNib()
            
            // 1. Visuals
            bubbleView.backgroundColor = .systemGray5
            messageLabel.textColor = .black
            avatarImageView.layer.cornerRadius = 15
            avatarImageView.clipsToBounds = true
            bubbleView.layer.cornerRadius = 16
            bubbleView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMaxYCorner]
            
            // 2. THE FIX: Force the cell width to match the Screen Width
            contentView.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width).isActive = true
        }
    }

