//
//  Model..swift
//  Quick Captioning.
//
//  Created by SDC-USER on 25/11/25.
//

import Foundation

// The basic message data
struct Message {
    let text: String
    let isSender: Bool
}

// A helper struct to manage our "Auto-Typing" script
struct ScriptLine {
    let text: String
    let isSender: Bool
    let delay: TimeInterval // How long to wait before showing this line
}
