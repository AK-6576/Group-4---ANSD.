import UIKit

class QuickCaptionsViewController: UIViewController {
    
    // MARK: - Data Source
    private var messages: [Message] = []
    
    // The Script
    private let conversationScript: [ScriptLine] = [
        ScriptLine(text: "You want me to drop you at the gate or that building? Same fare.", isSender: false, delay: 1.0),
        ScriptLine(text: "The gate would be fine, thanks.", isSender: true, delay: 2.0),
        ScriptLine(text: "What is the code, Sir?", isSender: false, delay: 1.5),
        ScriptLine(text: "The code is 10042005.", isSender: true, delay: 1.5),
        ScriptLine(text: "The fare is 120 bucks, Sir. Cash please.", isSender: false, delay: 2.0),
        ScriptLine(text: "120 ! Jesus, the fare has sky-rocketed a lot !", isSender: true, delay: 2.0),
        ScriptLine(text: "I know, Sir. But after inflation, this is the best we can do.", isSender: false, delay: 2.0),
        ScriptLine(text: "Public transport would have been cheaper.", isSender: true, delay: 2.0),
        ScriptLine(text: "Hey, no one is forcing you to take a cab. Your choice.", isSender: false, delay: 2.0),
        ScriptLine(text: "Yeah yeah, I know. Spare me the lecture.", isSender: true, delay: 2.0)
    ]
    
    // MARK: - UI Components
    
    private lazy var headerView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var backButton: UIButton = {
        let btn = UIButton(type: .custom) // Changed to .custom for better control
        // Icon
        let config = UIImage.SymbolConfiguration(pointSize: 14, weight: .bold)
        let image = UIImage(systemName: "chevron.left", withConfiguration: config)
        btn.setImage(image, for: .normal)
        
        // Styling (White Circle)
        btn.tintColor = .black
        btn.backgroundColor = .systemGray5
        btn.layer.cornerRadius = 20
        
        // Shadow
        btn.layer.shadowColor = UIColor.black.cgColor
        btn.layer.shadowOpacity = 0.1
        btn.layer.shadowOffset = CGSize(width: 0, height: 2)
        btn.layer.shadowRadius = 4
        
        btn.addTarget(self, action: #selector(handleBack), for: .touchUpInside)
        return btn
    }()
    
    private lazy var titleLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "Quick Captioning"
        lbl.font = .systemFont(ofSize: 17, weight: .semibold)
        lbl.textColor = .black
        return lbl
    }()
    
    private lazy var chatTableView: UITableView = {
        let tv = UITableView()
        tv.register(ChatMessageCell.self, forCellReuseIdentifier: ChatMessageCell.identifier)
        tv.separatorStyle = .none
        tv.backgroundColor = .white
        tv.allowsSelection = false
        

        tv.layer.cornerRadius = 24
        tv.layer.masksToBounds = true
        

        tv.contentInset = UIEdgeInsets(top: 9, left: 0, bottom: 20, right: 0)
        
        tv.delegate = self
        tv.dataSource = self
        return tv
    }()
    

    private lazy var pauseButton = createControlButton(iconName: "pause.fill")
    private lazy var micButton = createControlButton(iconName: "mic.fill")
    private lazy var stopButton = createControlButton(iconName: "square.fill")
    
    private lazy var controlStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [pauseButton, micButton, stopButton])
        stack.axis = .horizontal
        stack.distribution = .equalSpacing
        stack.alignment = .center
        return stack
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.systemGray6
        
        setupLayout()
        runScript()
    }
    
    // MARK: - Logic
    
    private func runScript() {
        var accumulatedDelay: TimeInterval = 0
        for line in conversationScript {
            accumulatedDelay += line.delay
            DispatchQueue.main.asyncAfter(deadline: .now() + accumulatedDelay) { [weak self] in
                self?.addNewMessage(line.text, isSender: line.isSender)
            }
        }
    }
    
    private func addNewMessage(_ text: String, isSender: Bool) {
        messages.append(Message(text: text, isSender: isSender))
        let newIndexPath = IndexPath(row: messages.count - 1, section: 0)
        chatTableView.insertRows(at: [newIndexPath], with: .bottom)
        chatTableView.scrollToRow(at: newIndexPath, at: .bottom, animated: true)
    }
    
    @objc private func handleBack() {
        dismiss(animated: true)
    }
    
    // MARK: - Helper for Buttons
    
    private func createControlButton(iconName: String) -> UIButton {
        let btn = UIButton(type: .system)
        // BOLDER ICONS
        let config = UIImage.SymbolConfiguration(pointSize: 9, weight: .heavy)
        btn.setImage(UIImage(systemName: iconName, withConfiguration: config), for: .normal)
        btn.tintColor = .black
        btn.backgroundColor = UIColor.systemGray5
        btn.layer.cornerRadius = 25
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            btn.widthAnchor.constraint(equalToConstant: 110),
            btn.heightAnchor.constraint(equalToConstant: 50)
        ])
        return btn
    }
    
    // MARK: - Layout Setup
    
    private func setupLayout() {
        view.addSubview(headerView)
        headerView.addSubview(backButton)
        headerView.addSubview(titleLabel)
        view.addSubview(chatTableView)
        view.addSubview(controlStack)
        
        [headerView, backButton, titleLabel, chatTableView, controlStack].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
        
        NSLayoutConstraint.activate([
            // Header
            headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 50),
            
            // Back Button (Explicit Size for Circle)
            backButton.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            backButton.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            backButton.widthAnchor.constraint(equalToConstant: 40),
            backButton.heightAnchor.constraint(equalToConstant: 40),
            
            // Title
            titleLabel.centerXAnchor.constraint(equalTo: headerView.centerXAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            
            // White Card (Dynamic Height)
            // It pins to Header at top, and Control Stack at bottom
            chatTableView.topAnchor.constraint(equalTo: headerView.bottomAnchor, constant: 10),
            chatTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12),
            chatTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
            chatTableView.bottomAnchor.constraint(equalTo: controlStack.topAnchor, constant: -20),
            
            // Bottom Controls
            controlStack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            controlStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            controlStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            controlStack.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
}

// MARK: - 3. TABLEVIEW DELEGATE

extension QuickCaptionsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ChatMessageCell.identifier, for: indexPath) as? ChatMessageCell else { return UITableViewCell() }
        cell.configure(with: messages[indexPath.row])
        return cell
    }
}

// MARK: - 4. THE VIEW (Custom Cell)

class ChatMessageCell: UITableViewCell {
    
    static let identifier = "ChatMessageCell"
    
    private let bubbleBackgroundView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 16
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let messageLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 17)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let avatarImageView: UIImageView = {
        let iv = UIImageView()
        iv.backgroundColor = .systemGray4
        iv.layer.cornerRadius = 16
        iv.clipsToBounds = true
        iv.contentMode = .scaleAspectFill
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Person 1"
        label.font = .systemFont(ofSize: 11, weight: .regular)
        label.textColor = .systemGray
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private var leadingConstraint: NSLayoutConstraint!
    private var trailingConstraint: NSLayoutConstraint!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) { fatalError() }
    
    private func setupUI() {
        backgroundColor = .clear
        selectionStyle = .none
        
        contentView.addSubview(avatarImageView)
        contentView.addSubview(nameLabel)
        contentView.addSubview(bubbleBackgroundView)
        bubbleBackgroundView.addSubview(messageLabel)
        
        NSLayoutConstraint.activate([
            // Avatar
            avatarImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            avatarImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            avatarImageView.widthAnchor.constraint(equalToConstant: 32),
            avatarImageView.heightAnchor.constraint(equalToConstant: 32),
            
            // Name
            nameLabel.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 8),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 4),
            
            // Message
            messageLabel.topAnchor.constraint(equalTo: bubbleBackgroundView.topAnchor, constant: 10),
            messageLabel.bottomAnchor.constraint(equalTo: bubbleBackgroundView.bottomAnchor, constant: -10),
            messageLabel.leadingAnchor.constraint(equalTo: bubbleBackgroundView.leadingAnchor, constant: 12),
            messageLabel.trailingAnchor.constraint(equalTo: bubbleBackgroundView.trailingAnchor, constant: -12),
            
            // Bubble
            bubbleBackgroundView.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            bubbleBackgroundView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12),
            bubbleBackgroundView.widthAnchor.constraint(lessThanOrEqualToConstant: 280)
        ])
        
        leadingConstraint = bubbleBackgroundView.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 8)
        trailingConstraint = bubbleBackgroundView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16)
    }
    
    func configure(with message: Message) {
        messageLabel.text = message.text
        
        if message.isSender {
            bubbleBackgroundView.backgroundColor = .systemBlue
            messageLabel.textColor = .white
            avatarImageView.isHidden = true
            nameLabel.isHidden = true
            leadingConstraint.isActive = false
            trailingConstraint.isActive = true
        } else {
            bubbleBackgroundView.backgroundColor = UIColor.systemGray6
            messageLabel.textColor = .black
            avatarImageView.isHidden = false
            nameLabel.isHidden = false
            trailingConstraint.isActive = false
            leadingConstraint.isActive = true
            
            // Try to load a real image named "AvatarImage" from Assets
            if let image = UIImage(named: "AvatarImage") {
                avatarImageView.image = image
            } else {
                // Fallback: Green circle with person icon (Like Figma)
                avatarImageView.image = UIImage(systemName: "person.fill")
                avatarImageView.tintColor = .white
                avatarImageView.backgroundColor = UIColor.systemGray
            }
        }
    }
}
